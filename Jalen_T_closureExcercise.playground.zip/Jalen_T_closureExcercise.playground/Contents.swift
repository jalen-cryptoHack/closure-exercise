import UIKit
var mult : (Int, Int)-> Int = {(num1, num2) in
return num1 + num2
}
mult(23,36)
print("23 * 36 = \(mult(23,36))")
